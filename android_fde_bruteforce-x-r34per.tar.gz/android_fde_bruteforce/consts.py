#The keymaster KDF
KDF_SCRYPT_KEYMASTER = 5

#The crypto footer magic
CRYPT_MNT_MAGIC = 0xD0B5B1C4

#The key lengths used
KEY_LEN_BYTES = 16
IV_LEN_BYTES = 16
SCRYPT_LEN = 32
