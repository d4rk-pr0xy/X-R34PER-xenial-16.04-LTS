#define CRYPTO_NSECBYTES 	 				0
#define CRYPTO_NPUBBYTES 					64
#define CRYPTO_KEYBYTES 	        32
#define CRYPTO_ABYTES 					  64
