#define KeccakP800_implementation_config "lane complementing, all rounds unrolled"
#define KeccakP800_fullUnrolling
#define KeccakP800_useLaneComplementing
