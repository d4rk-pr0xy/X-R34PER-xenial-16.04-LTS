#define KeccakP1600_implementation_config "all rounds unrolled"
#define KeccakP1600_fullUnrolling
