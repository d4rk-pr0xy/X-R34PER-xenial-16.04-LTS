This is the optimized implementation of omd-sha512 intended for the CAESAR competition. Documentation can be built using doxygen.
* This package was built successfully on Linux using
	- gcc (Ubuntu/Linaro 4.7.2-2ubuntu1) 4.7.2 
	- GNU assembler (GNU Binutils for Ubuntu) 2.22.90.20120924
* Documentation can be built using doxygen.
