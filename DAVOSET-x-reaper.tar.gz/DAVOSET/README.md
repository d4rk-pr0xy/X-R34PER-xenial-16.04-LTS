DDoS attacks via other sites execution tool
DAVOSET v.1.2.8
Tool for conducting of DDoS attacks on the sites via other sites
Copyright (C) MustLive 2010-2016
Last update: 26.03.2016
http://websecurity.com.ua

DAVOSET - it is console (command line) tool for conducting DDoS attacks on the sites via Abuse of Functionality and XML External Entities vulnerabilities at other sites.

About such attacks you can read in my article "Using of the sites for attacks on other sites" (http://websecurity.com.ua/4322/).

Video demonstration of DAVOSET: http://www.youtube.com/watch?v=RKi35-f346I
